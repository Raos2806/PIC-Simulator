﻿namespace PIC_Controller
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            DataGridViewCellStyle dataGridViewCellStyle1 = new DataGridViewCellStyle();
            panel1 = new Panel();
            label43 = new Label();
            label44 = new Label();
            label45 = new Label();
            label46 = new Label();
            label47 = new Label();
            label59 = new Label();
            label60 = new Label();
            label61 = new Label();
            textBox2 = new TextBox();
            textBox3 = new TextBox();
            textBox4 = new TextBox();
            textBox23 = new TextBox();
            textBox24 = new TextBox();
            textBox25 = new TextBox();
            textBox26 = new TextBox();
            textBox27 = new TextBox();
            label23 = new Label();
            label24 = new Label();
            label20 = new Label();
            intcon_out = new TextBox();
            label19 = new Label();
            label25 = new Label();
            option_out = new TextBox();
            label26 = new Label();
            label18 = new Label();
            label27 = new Label();
            label12 = new Label();
            label38 = new Label();
            label17 = new Label();
            label40 = new Label();
            label41 = new Label();
            label16 = new Label();
            label15 = new Label();
            label42 = new Label();
            RBIF_Toggle = new TextBox();
            label14 = new Label();
            INTF_Toggle = new TextBox();
            T0IF_Toggle = new TextBox();
            label13 = new Label();
            RBIE_Toggle = new TextBox();
            INTE_Toggle = new TextBox();
            PS0_Toggle = new TextBox();
            T0IE_Toggle = new TextBox();
            PS1_Toggle = new TextBox();
            PIE_Toggle = new TextBox();
            PS2_Toggle = new TextBox();
            GIE_Toggle = new TextBox();
            PSA_Toggle = new TextBox();
            panel5 = new Panel();
            tableLayoutPanel7 = new TableLayoutPanel();
            TrisB0_label = new Label();
            TrisB1_label = new Label();
            TrisB2_label = new Label();
            TrisB3_label = new Label();
            TrisB4_label = new Label();
            TrisB5_label = new Label();
            TrisB6_label = new Label();
            TrisB7_label = new Label();
            label48 = new Label();
            label49 = new Label();
            label50 = new Label();
            label51 = new Label();
            label52 = new Label();
            label53 = new Label();
            label54 = new Label();
            label55 = new Label();
            label56 = new Label();
            label57 = new Label();
            label58 = new Label();
            PinB5_button = new Button();
            PinB4_button = new Button();
            PinB2_button = new Button();
            PinB3_button = new Button();
            PinB6_button = new Button();
            PinB7_button = new Button();
            PinB1_button = new Button();
            PinB0_button = new Button();
            tableLayoutPanel6 = new TableLayoutPanel();
            TrisA0_label = new Label();
            TrisA1_label = new Label();
            TrisA2_label = new Label();
            TrisA3_label = new Label();
            TrisA4_label = new Label();
            TrisA5_label = new Label();
            TrisA6_label = new Label();
            TrisA7_label = new Label();
            label37 = new Label();
            label36 = new Label();
            label35 = new Label();
            label34 = new Label();
            label33 = new Label();
            label32 = new Label();
            label31 = new Label();
            label30 = new Label();
            label29 = new Label();
            label28 = new Label();
            label39 = new Label();
            PinA5_button = new Button();
            PinA4_button = new Button();
            PinA2_button = new Button();
            PinA3_button = new Button();
            PinA6_button = new Button();
            PinA7_button = new Button();
            PinA1_button = new Button();
            PinA0_button = new Button();
            T0SE_Toggle = new TextBox();
            panel4 = new Panel();
            dataGridView1 = new DataGridView();
            Column9 = new DataGridViewTextBoxColumn();
            Column1 = new DataGridViewTextBoxColumn();
            Column2 = new DataGridViewTextBoxColumn();
            Column3 = new DataGridViewTextBoxColumn();
            Column4 = new DataGridViewTextBoxColumn();
            Column5 = new DataGridViewTextBoxColumn();
            Column6 = new DataGridViewTextBoxColumn();
            Column7 = new DataGridViewTextBoxColumn();
            Column8 = new DataGridViewTextBoxColumn();
            panel3 = new Panel();
            Status = new Label();
            textBox5 = new TextBox();
            textBox10 = new TextBox();
            label6 = new Label();
            label5 = new Label();
            textBox1 = new TextBox();
            label7 = new Label();
            label9 = new Label();
            textBox9 = new TextBox();
            label1 = new Label();
            textBox6 = new TextBox();
            textBox7 = new TextBox();
            label8 = new Label();
            textBox8 = new TextBox();
            panel2 = new Panel();
            label22 = new Label();
            label21 = new Label();
            quarzFreq_comboBox = new ComboBox();
            BP_skip_CB = new CheckBox();
            Einlesen_Btn = new Button();
            label10 = new Label();
            laufzeit_TB = new TextBox();
            Automatic_Btn = new Button();
            zykluszeit_TB = new TextBox();
            Zurücksetzen_Btn = new Button();
            label11 = new Label();
            Einzelschritt_Btn = new Button();
            T0CS_Toggle = new TextBox();
            Ausgabe_LV = new ListView();
            Textanzeige_LV = new ColumnHeader();
            INTEDG_Toggle = new TextBox();
            RPBU_Toggle = new TextBox();
            panel1.SuspendLayout();
            panel5.SuspendLayout();
            tableLayoutPanel7.SuspendLayout();
            tableLayoutPanel6.SuspendLayout();
            panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            panel3.SuspendLayout();
            panel2.SuspendLayout();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            panel1.CausesValidation = false;
            panel1.Controls.Add(label43);
            panel1.Controls.Add(label44);
            panel1.Controls.Add(label45);
            panel1.Controls.Add(label46);
            panel1.Controls.Add(label47);
            panel1.Controls.Add(label59);
            panel1.Controls.Add(label60);
            panel1.Controls.Add(label61);
            panel1.Controls.Add(textBox2);
            panel1.Controls.Add(textBox3);
            panel1.Controls.Add(textBox4);
            panel1.Controls.Add(textBox23);
            panel1.Controls.Add(textBox24);
            panel1.Controls.Add(textBox25);
            panel1.Controls.Add(textBox26);
            panel1.Controls.Add(textBox27);
            panel1.Controls.Add(label23);
            panel1.Controls.Add(label24);
            panel1.Controls.Add(label20);
            panel1.Controls.Add(intcon_out);
            panel1.Controls.Add(label19);
            panel1.Controls.Add(label25);
            panel1.Controls.Add(option_out);
            panel1.Controls.Add(label26);
            panel1.Controls.Add(label18);
            panel1.Controls.Add(label27);
            panel1.Controls.Add(label12);
            panel1.Controls.Add(label38);
            panel1.Controls.Add(label17);
            panel1.Controls.Add(label40);
            panel1.Controls.Add(label41);
            panel1.Controls.Add(label16);
            panel1.Controls.Add(label15);
            panel1.Controls.Add(label42);
            panel1.Controls.Add(RBIF_Toggle);
            panel1.Controls.Add(label14);
            panel1.Controls.Add(INTF_Toggle);
            panel1.Controls.Add(T0IF_Toggle);
            panel1.Controls.Add(label13);
            panel1.Controls.Add(RBIE_Toggle);
            panel1.Controls.Add(INTE_Toggle);
            panel1.Controls.Add(PS0_Toggle);
            panel1.Controls.Add(T0IE_Toggle);
            panel1.Controls.Add(PS1_Toggle);
            panel1.Controls.Add(PIE_Toggle);
            panel1.Controls.Add(PS2_Toggle);
            panel1.Controls.Add(GIE_Toggle);
            panel1.Controls.Add(PSA_Toggle);
            panel1.Controls.Add(panel5);
            panel1.Controls.Add(T0SE_Toggle);
            panel1.Controls.Add(panel4);
            panel1.Controls.Add(panel2);
            panel1.Controls.Add(T0CS_Toggle);
            panel1.Controls.Add(Ausgabe_LV);
            panel1.Controls.Add(INTEDG_Toggle);
            panel1.Controls.Add(RPBU_Toggle);
            panel1.Dock = DockStyle.Fill;
            panel1.Location = new Point(0, 0);
            panel1.Margin = new Padding(3, 2, 3, 2);
            panel1.Name = "panel1";
            panel1.Size = new Size(1404, 587);
            panel1.TabIndex = 0;
            // 
            // label43
            // 
            label43.AutoSize = true;
            label43.Font = new Font("Arial", 8.25F, FontStyle.Regular, GraphicsUnit.Point);
            label43.Location = new Point(750, 362);
            label43.Name = "label43";
            label43.Size = new Size(14, 14);
            label43.TabIndex = 149;
            label43.Text = "C";
            // 
            // label44
            // 
            label44.AutoSize = true;
            label44.Font = new Font("Arial", 8.25F, FontStyle.Regular, GraphicsUnit.Point);
            label44.Location = new Point(708, 363);
            label44.Name = "label44";
            label44.Size = new Size(21, 14);
            label44.TabIndex = 148;
            label44.Text = "DC";
            // 
            // label45
            // 
            label45.AutoSize = true;
            label45.Font = new Font("Arial", 8.25F, FontStyle.Regular, GraphicsUnit.Point);
            label45.Location = new Point(674, 362);
            label45.Name = "label45";
            label45.Size = new Size(14, 14);
            label45.TabIndex = 147;
            label45.Text = "Z";
            // 
            // label46
            // 
            label46.AutoSize = true;
            label46.Font = new Font("Arial", 8.25F, FontStyle.Regular, GraphicsUnit.Point);
            label46.Location = new Point(631, 363);
            label46.Name = "label46";
            label46.Size = new Size(20, 14);
            label46.TabIndex = 146;
            label46.Text = "PD";
            // 
            // label47
            // 
            label47.AutoSize = true;
            label47.Font = new Font("Arial", 8.25F, FontStyle.Regular, GraphicsUnit.Point);
            label47.Location = new Point(592, 363);
            label47.Name = "label47";
            label47.Size = new Size(21, 14);
            label47.TabIndex = 145;
            label47.Text = "TO";
            // 
            // label59
            // 
            label59.AutoSize = true;
            label59.Font = new Font("Arial", 8.25F, FontStyle.Regular, GraphicsUnit.Point);
            label59.Location = new Point(553, 363);
            label59.Name = "label59";
            label59.Size = new Size(26, 14);
            label59.TabIndex = 144;
            label59.Text = "RP0";
            // 
            // label60
            // 
            label60.AutoSize = true;
            label60.Font = new Font("Arial", 8.25F, FontStyle.Regular, GraphicsUnit.Point);
            label60.Location = new Point(516, 362);
            label60.Name = "label60";
            label60.Size = new Size(26, 14);
            label60.TabIndex = 143;
            label60.Text = "RP1";
            // 
            // label61
            // 
            label61.AutoSize = true;
            label61.Font = new Font("Arial", 8.25F, FontStyle.Regular, GraphicsUnit.Point);
            label61.Location = new Point(484, 362);
            label61.Name = "label61";
            label61.Size = new Size(22, 14);
            label61.TabIndex = 134;
            label61.Text = "IRP";
            // 
            // textBox2
            // 
            textBox2.Font = new Font("Arial", 9F, FontStyle.Bold, GraphicsUnit.Point);
            textBox2.Location = new Point(750, 382);
            textBox2.Name = "textBox2";
            textBox2.ReadOnly = true;
            textBox2.Size = new Size(16, 21);
            textBox2.TabIndex = 142;
            textBox2.TabStop = false;
            textBox2.TextAlign = HorizontalAlignment.Center;
            textBox2.TextChanged += textBox2_TextChanged;
            // 
            // textBox3
            // 
            textBox3.Font = new Font("Arial", 9F, FontStyle.Bold, GraphicsUnit.Point);
            textBox3.Location = new Point(712, 382);
            textBox3.Name = "textBox3";
            textBox3.ReadOnly = true;
            textBox3.Size = new Size(16, 21);
            textBox3.TabIndex = 141;
            textBox3.TabStop = false;
            textBox3.TextAlign = HorizontalAlignment.Center;
            textBox3.TextChanged += textBox3_TextChanged;
            // 
            // textBox4
            // 
            textBox4.Font = new Font("Arial", 9F, FontStyle.Bold, GraphicsUnit.Point);
            textBox4.Location = new Point(674, 382);
            textBox4.Name = "textBox4";
            textBox4.ReadOnly = true;
            textBox4.Size = new Size(16, 21);
            textBox4.TabIndex = 140;
            textBox4.TabStop = false;
            textBox4.TextAlign = HorizontalAlignment.Center;
            textBox4.TextChanged += textBox4_TextChanged;
            // 
            // textBox23
            // 
            textBox23.Font = new Font("Arial", 9F, FontStyle.Bold, GraphicsUnit.Point);
            textBox23.Location = new Point(636, 382);
            textBox23.Name = "textBox23";
            textBox23.ReadOnly = true;
            textBox23.Size = new Size(16, 21);
            textBox23.TabIndex = 139;
            textBox23.TabStop = false;
            textBox23.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox24
            // 
            textBox24.Font = new Font("Arial", 9F, FontStyle.Bold, GraphicsUnit.Point);
            textBox24.Location = new Point(598, 382);
            textBox24.Name = "textBox24";
            textBox24.ReadOnly = true;
            textBox24.Size = new Size(16, 21);
            textBox24.TabIndex = 138;
            textBox24.TabStop = false;
            textBox24.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox25
            // 
            textBox25.Font = new Font("Arial", 9F, FontStyle.Bold, GraphicsUnit.Point);
            textBox25.Location = new Point(560, 382);
            textBox25.Name = "textBox25";
            textBox25.ReadOnly = true;
            textBox25.Size = new Size(16, 21);
            textBox25.TabIndex = 137;
            textBox25.TabStop = false;
            textBox25.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox26
            // 
            textBox26.Font = new Font("Arial", 9F, FontStyle.Bold, GraphicsUnit.Point);
            textBox26.Location = new Point(522, 382);
            textBox26.Name = "textBox26";
            textBox26.ReadOnly = true;
            textBox26.Size = new Size(16, 21);
            textBox26.TabIndex = 136;
            textBox26.TabStop = false;
            textBox26.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox27
            // 
            textBox27.Font = new Font("Arial", 9F, FontStyle.Bold, GraphicsUnit.Point);
            textBox27.Location = new Point(484, 382);
            textBox27.Name = "textBox27";
            textBox27.ReadOnly = true;
            textBox27.Size = new Size(16, 21);
            textBox27.TabIndex = 135;
            textBox27.TabStop = false;
            textBox27.TextAlign = HorizontalAlignment.Center;
            // 
            // label23
            // 
            label23.AutoSize = true;
            label23.Font = new Font("Arial", 8.25F, FontStyle.Regular, GraphicsUnit.Point);
            label23.Location = new Point(746, 525);
            label23.Name = "label23";
            label23.Size = new Size(29, 14);
            label23.TabIndex = 133;
            label23.Text = "RBIF";
            // 
            // label24
            // 
            label24.AutoSize = true;
            label24.Font = new Font("Arial", 8.25F, FontStyle.Regular, GraphicsUnit.Point);
            label24.Location = new Point(708, 525);
            label24.Name = "label24";
            label24.Size = new Size(28, 14);
            label24.TabIndex = 132;
            label24.Text = "INTF";
            // 
            // label20
            // 
            label20.AutoSize = true;
            label20.Font = new Font("Arial", 8.25F, FontStyle.Regular, GraphicsUnit.Point);
            label20.Location = new Point(746, 443);
            label20.Name = "label20";
            label20.Size = new Size(26, 14);
            label20.TabIndex = 115;
            label20.Text = "PS0";
            // 
            // intcon_out
            // 
            intcon_out.Location = new Point(572, 497);
            intcon_out.Name = "intcon_out";
            intcon_out.ReadOnly = true;
            intcon_out.Size = new Size(39, 23);
            intcon_out.TabIndex = 117;
            intcon_out.TabStop = false;
            // 
            // label19
            // 
            label19.AutoSize = true;
            label19.Font = new Font("Arial", 8.25F, FontStyle.Regular, GraphicsUnit.Point);
            label19.Location = new Point(708, 443);
            label19.Name = "label19";
            label19.Size = new Size(26, 14);
            label19.TabIndex = 114;
            label19.Text = "PS1";
            // 
            // label25
            // 
            label25.AutoSize = true;
            label25.Font = new Font("Arial", 8.25F, FontStyle.Regular, GraphicsUnit.Point);
            label25.Location = new Point(670, 525);
            label25.Name = "label25";
            label25.Size = new Size(27, 14);
            label25.TabIndex = 131;
            label25.Text = "T0IF";
            // 
            // option_out
            // 
            option_out.Location = new Point(572, 415);
            option_out.Name = "option_out";
            option_out.ReadOnly = true;
            option_out.Size = new Size(39, 23);
            option_out.TabIndex = 25;
            option_out.TabStop = false;
            // 
            // label26
            // 
            label26.AutoSize = true;
            label26.Location = new Point(474, 500);
            label26.Name = "label26";
            label26.Size = new Size(50, 15);
            label26.TabIndex = 116;
            label26.Text = "INTCON";
            // 
            // label18
            // 
            label18.AutoSize = true;
            label18.Font = new Font("Arial", 8.25F, FontStyle.Regular, GraphicsUnit.Point);
            label18.Location = new Point(670, 443);
            label18.Name = "label18";
            label18.Size = new Size(26, 14);
            label18.TabIndex = 113;
            label18.Text = "PS2";
            // 
            // label27
            // 
            label27.AutoSize = true;
            label27.Font = new Font("Arial", 8.25F, FontStyle.Regular, GraphicsUnit.Point);
            label27.Location = new Point(631, 525);
            label27.Name = "label27";
            label27.Size = new Size(29, 14);
            label27.TabIndex = 130;
            label27.Text = "RBIE";
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Location = new Point(474, 418);
            label12.Name = "label12";
            label12.Size = new Size(88, 15);
            label12.TabIndex = 24;
            label12.Text = "Optionsregister";
            // 
            // label38
            // 
            label38.AutoSize = true;
            label38.Font = new Font("Arial", 8.25F, FontStyle.Regular, GraphicsUnit.Point);
            label38.Location = new Point(592, 525);
            label38.Name = "label38";
            label38.Size = new Size(28, 14);
            label38.TabIndex = 129;
            label38.Text = "INTE";
            // 
            // label17
            // 
            label17.AutoSize = true;
            label17.Font = new Font("Arial", 8.25F, FontStyle.Regular, GraphicsUnit.Point);
            label17.Location = new Point(631, 443);
            label17.Name = "label17";
            label17.Size = new Size(28, 14);
            label17.TabIndex = 112;
            label17.Text = "PSA";
            // 
            // label40
            // 
            label40.AutoSize = true;
            label40.Font = new Font("Arial", 8.25F, FontStyle.Regular, GraphicsUnit.Point);
            label40.Location = new Point(553, 525);
            label40.Name = "label40";
            label40.Size = new Size(27, 14);
            label40.TabIndex = 128;
            label40.Text = "T0IE";
            // 
            // label41
            // 
            label41.AutoSize = true;
            label41.Font = new Font("Arial", 8.25F, FontStyle.Regular, GraphicsUnit.Point);
            label41.Location = new Point(522, 525);
            label41.Name = "label41";
            label41.Size = new Size(21, 14);
            label41.TabIndex = 127;
            label41.Text = "PIE";
            // 
            // label16
            // 
            label16.AutoSize = true;
            label16.Font = new Font("Arial", 8.25F, FontStyle.Regular, GraphicsUnit.Point);
            label16.Location = new Point(592, 443);
            label16.Name = "label16";
            label16.Size = new Size(32, 14);
            label16.TabIndex = 111;
            label16.Text = "T0SE";
            // 
            // label15
            // 
            label15.AutoSize = true;
            label15.Font = new Font("Arial", 8.25F, FontStyle.Regular, GraphicsUnit.Point);
            label15.Location = new Point(553, 443);
            label15.Name = "label15";
            label15.Size = new Size(33, 14);
            label15.TabIndex = 110;
            label15.Text = "T0CS";
            // 
            // label42
            // 
            label42.AutoSize = true;
            label42.Font = new Font("Arial", 8.25F, FontStyle.Regular, GraphicsUnit.Point);
            label42.Location = new Point(480, 525);
            label42.Name = "label42";
            label42.Size = new Size(23, 14);
            label42.TabIndex = 119;
            label42.Text = "GIE";
            // 
            // RBIF_Toggle
            // 
            RBIF_Toggle.Font = new Font("Arial", 9F, FontStyle.Bold, GraphicsUnit.Point);
            RBIF_Toggle.Location = new Point(750, 544);
            RBIF_Toggle.Name = "RBIF_Toggle";
            RBIF_Toggle.ReadOnly = true;
            RBIF_Toggle.Size = new Size(16, 21);
            RBIF_Toggle.TabIndex = 126;
            RBIF_Toggle.TabStop = false;
            RBIF_Toggle.TextAlign = HorizontalAlignment.Center;
            RBIF_Toggle.MouseClick += RBIF_Toggle_MouseClick;
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.Font = new Font("Arial", 8.25F, FontStyle.Regular, GraphicsUnit.Point);
            label14.Location = new Point(510, 443);
            label14.Name = "label14";
            label14.Size = new Size(43, 14);
            label14.TabIndex = 109;
            label14.Text = "INTEDG";
            // 
            // INTF_Toggle
            // 
            INTF_Toggle.Font = new Font("Arial", 9F, FontStyle.Bold, GraphicsUnit.Point);
            INTF_Toggle.Location = new Point(712, 544);
            INTF_Toggle.Name = "INTF_Toggle";
            INTF_Toggle.ReadOnly = true;
            INTF_Toggle.Size = new Size(16, 21);
            INTF_Toggle.TabIndex = 125;
            INTF_Toggle.TabStop = false;
            INTF_Toggle.TextAlign = HorizontalAlignment.Center;
            INTF_Toggle.MouseClick += INTF_Toggle_MouseClick;
            // 
            // T0IF_Toggle
            // 
            T0IF_Toggle.Font = new Font("Arial", 9F, FontStyle.Bold, GraphicsUnit.Point);
            T0IF_Toggle.Location = new Point(674, 544);
            T0IF_Toggle.Name = "T0IF_Toggle";
            T0IF_Toggle.ReadOnly = true;
            T0IF_Toggle.Size = new Size(16, 21);
            T0IF_Toggle.TabIndex = 124;
            T0IF_Toggle.TabStop = false;
            T0IF_Toggle.TextAlign = HorizontalAlignment.Center;
            T0IF_Toggle.MouseClick += T0IF_Toggle_MouseClick;
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Font = new Font("Arial", 8.25F, FontStyle.Regular, GraphicsUnit.Point);
            label13.Location = new Point(476, 443);
            label13.Name = "label13";
            label13.Size = new Size(34, 14);
            label13.TabIndex = 27;
            label13.Text = "RBPU";
            // 
            // RBIE_Toggle
            // 
            RBIE_Toggle.Font = new Font("Arial", 9F, FontStyle.Bold, GraphicsUnit.Point);
            RBIE_Toggle.Location = new Point(636, 544);
            RBIE_Toggle.Name = "RBIE_Toggle";
            RBIE_Toggle.ReadOnly = true;
            RBIE_Toggle.Size = new Size(16, 21);
            RBIE_Toggle.TabIndex = 123;
            RBIE_Toggle.TabStop = false;
            RBIE_Toggle.TextAlign = HorizontalAlignment.Center;
            RBIE_Toggle.MouseClick += RBIE_Toggle_MouseClick;
            // 
            // INTE_Toggle
            // 
            INTE_Toggle.Font = new Font("Arial", 9F, FontStyle.Bold, GraphicsUnit.Point);
            INTE_Toggle.Location = new Point(598, 544);
            INTE_Toggle.Name = "INTE_Toggle";
            INTE_Toggle.ReadOnly = true;
            INTE_Toggle.Size = new Size(16, 21);
            INTE_Toggle.TabIndex = 122;
            INTE_Toggle.TabStop = false;
            INTE_Toggle.TextAlign = HorizontalAlignment.Center;
            INTE_Toggle.MouseClick += INTE_Toggle_MouseClick;
            // 
            // PS0_Toggle
            // 
            PS0_Toggle.Font = new Font("Arial", 9F, FontStyle.Bold, GraphicsUnit.Point);
            PS0_Toggle.Location = new Point(750, 462);
            PS0_Toggle.Name = "PS0_Toggle";
            PS0_Toggle.ReadOnly = true;
            PS0_Toggle.Size = new Size(16, 21);
            PS0_Toggle.TabIndex = 108;
            PS0_Toggle.TabStop = false;
            PS0_Toggle.TextAlign = HorizontalAlignment.Center;
            PS0_Toggle.MouseClick += PS0_Toggle_MouseClick;
            // 
            // T0IE_Toggle
            // 
            T0IE_Toggle.Font = new Font("Arial", 9F, FontStyle.Bold, GraphicsUnit.Point);
            T0IE_Toggle.Location = new Point(560, 544);
            T0IE_Toggle.Name = "T0IE_Toggle";
            T0IE_Toggle.ReadOnly = true;
            T0IE_Toggle.Size = new Size(16, 21);
            T0IE_Toggle.TabIndex = 121;
            T0IE_Toggle.TabStop = false;
            T0IE_Toggle.TextAlign = HorizontalAlignment.Center;
            T0IE_Toggle.MouseClick += T0IE_Toggle_MouseClick;
            // 
            // PS1_Toggle
            // 
            PS1_Toggle.Font = new Font("Arial", 9F, FontStyle.Bold, GraphicsUnit.Point);
            PS1_Toggle.Location = new Point(712, 462);
            PS1_Toggle.Name = "PS1_Toggle";
            PS1_Toggle.ReadOnly = true;
            PS1_Toggle.Size = new Size(16, 21);
            PS1_Toggle.TabIndex = 107;
            PS1_Toggle.TabStop = false;
            PS1_Toggle.TextAlign = HorizontalAlignment.Center;
            PS1_Toggle.MouseClick += PS1_Toggle_MouseClick;
            // 
            // PIE_Toggle
            // 
            PIE_Toggle.Font = new Font("Arial", 9F, FontStyle.Bold, GraphicsUnit.Point);
            PIE_Toggle.Location = new Point(522, 544);
            PIE_Toggle.Name = "PIE_Toggle";
            PIE_Toggle.ReadOnly = true;
            PIE_Toggle.Size = new Size(16, 21);
            PIE_Toggle.TabIndex = 120;
            PIE_Toggle.TabStop = false;
            PIE_Toggle.TextAlign = HorizontalAlignment.Center;
            PIE_Toggle.MouseClick += PIE_Toggle_MouseClick;
            // 
            // PS2_Toggle
            // 
            PS2_Toggle.Font = new Font("Arial", 9F, FontStyle.Bold, GraphicsUnit.Point);
            PS2_Toggle.Location = new Point(674, 462);
            PS2_Toggle.Name = "PS2_Toggle";
            PS2_Toggle.ReadOnly = true;
            PS2_Toggle.Size = new Size(16, 21);
            PS2_Toggle.TabIndex = 106;
            PS2_Toggle.TabStop = false;
            PS2_Toggle.TextAlign = HorizontalAlignment.Center;
            PS2_Toggle.MouseClick += PS2_Toggle_MouseClick;
            // 
            // GIE_Toggle
            // 
            GIE_Toggle.Font = new Font("Arial", 9F, FontStyle.Bold, GraphicsUnit.Point);
            GIE_Toggle.Location = new Point(484, 544);
            GIE_Toggle.Name = "GIE_Toggle";
            GIE_Toggle.ReadOnly = true;
            GIE_Toggle.Size = new Size(16, 21);
            GIE_Toggle.TabIndex = 118;
            GIE_Toggle.TabStop = false;
            GIE_Toggle.TextAlign = HorizontalAlignment.Center;
            GIE_Toggle.MouseClick += GIE_Toggle_MouseClick;
            // 
            // PSA_Toggle
            // 
            PSA_Toggle.Font = new Font("Arial", 9F, FontStyle.Bold, GraphicsUnit.Point);
            PSA_Toggle.Location = new Point(636, 462);
            PSA_Toggle.Name = "PSA_Toggle";
            PSA_Toggle.ReadOnly = true;
            PSA_Toggle.Size = new Size(16, 21);
            PSA_Toggle.TabIndex = 105;
            PSA_Toggle.TabStop = false;
            PSA_Toggle.TextAlign = HorizontalAlignment.Center;
            PSA_Toggle.MouseClick += PSA_Toggle_MouseClick;
            // 
            // panel5
            // 
            panel5.Controls.Add(tableLayoutPanel7);
            panel5.Controls.Add(tableLayoutPanel6);
            panel5.Location = new Point(418, 5);
            panel5.Margin = new Padding(3, 2, 3, 2);
            panel5.Name = "panel5";
            panel5.Size = new Size(382, 188);
            panel5.TabIndex = 104;
            // 
            // tableLayoutPanel7
            // 
            tableLayoutPanel7.CellBorderStyle = TableLayoutPanelCellBorderStyle.Single;
            tableLayoutPanel7.ColumnCount = 9;
            tableLayoutPanel7.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 12F));
            tableLayoutPanel7.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 11F));
            tableLayoutPanel7.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 11F));
            tableLayoutPanel7.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 11F));
            tableLayoutPanel7.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 11F));
            tableLayoutPanel7.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 11F));
            tableLayoutPanel7.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 11F));
            tableLayoutPanel7.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 11F));
            tableLayoutPanel7.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 11F));
            tableLayoutPanel7.Controls.Add(TrisB0_label, 8, 1);
            tableLayoutPanel7.Controls.Add(TrisB1_label, 7, 1);
            tableLayoutPanel7.Controls.Add(TrisB2_label, 6, 1);
            tableLayoutPanel7.Controls.Add(TrisB3_label, 5, 1);
            tableLayoutPanel7.Controls.Add(TrisB4_label, 4, 1);
            tableLayoutPanel7.Controls.Add(TrisB5_label, 3, 1);
            tableLayoutPanel7.Controls.Add(TrisB6_label, 2, 1);
            tableLayoutPanel7.Controls.Add(TrisB7_label, 1, 1);
            tableLayoutPanel7.Controls.Add(label48, 0, 1);
            tableLayoutPanel7.Controls.Add(label49, 8, 0);
            tableLayoutPanel7.Controls.Add(label50, 7, 0);
            tableLayoutPanel7.Controls.Add(label51, 6, 0);
            tableLayoutPanel7.Controls.Add(label52, 5, 0);
            tableLayoutPanel7.Controls.Add(label53, 4, 0);
            tableLayoutPanel7.Controls.Add(label54, 3, 0);
            tableLayoutPanel7.Controls.Add(label55, 2, 0);
            tableLayoutPanel7.Controls.Add(label56, 1, 0);
            tableLayoutPanel7.Controls.Add(label57, 0, 0);
            tableLayoutPanel7.Controls.Add(label58, 0, 2);
            tableLayoutPanel7.Controls.Add(PinB5_button, 3, 2);
            tableLayoutPanel7.Controls.Add(PinB4_button, 4, 2);
            tableLayoutPanel7.Controls.Add(PinB2_button, 6, 2);
            tableLayoutPanel7.Controls.Add(PinB3_button, 5, 2);
            tableLayoutPanel7.Controls.Add(PinB6_button, 2, 2);
            tableLayoutPanel7.Controls.Add(PinB7_button, 1, 2);
            tableLayoutPanel7.Controls.Add(PinB1_button, 7, 2);
            tableLayoutPanel7.Controls.Add(PinB0_button, 8, 2);
            tableLayoutPanel7.Font = new Font("Arial Narrow", 7.8F, FontStyle.Regular, GraphicsUnit.Point);
            tableLayoutPanel7.Location = new Point(3, 100);
            tableLayoutPanel7.Name = "tableLayoutPanel7";
            tableLayoutPanel7.RowCount = 3;
            tableLayoutPanel7.RowStyles.Add(new RowStyle(SizeType.Percent, 34F));
            tableLayoutPanel7.RowStyles.Add(new RowStyle(SizeType.Percent, 33F));
            tableLayoutPanel7.RowStyles.Add(new RowStyle(SizeType.Percent, 33F));
            tableLayoutPanel7.Size = new Size(375, 86);
            tableLayoutPanel7.TabIndex = 1;
            // 
            // TrisB0_label
            // 
            TrisB0_label.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            TrisB0_label.AutoSize = true;
            TrisB0_label.Location = new Point(335, 29);
            TrisB0_label.Name = "TrisB0_label";
            TrisB0_label.Size = new Size(36, 27);
            TrisB0_label.TabIndex = 17;
            TrisB0_label.Text = "TrisB0";
            TrisB0_label.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // TrisB1_label
            // 
            TrisB1_label.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            TrisB1_label.AutoSize = true;
            TrisB1_label.Location = new Point(294, 29);
            TrisB1_label.Name = "TrisB1_label";
            TrisB1_label.Size = new Size(34, 27);
            TrisB1_label.TabIndex = 16;
            TrisB1_label.Text = "TrisB1";
            TrisB1_label.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // TrisB2_label
            // 
            TrisB2_label.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            TrisB2_label.AutoSize = true;
            TrisB2_label.Location = new Point(253, 29);
            TrisB2_label.Name = "TrisB2_label";
            TrisB2_label.Size = new Size(34, 27);
            TrisB2_label.TabIndex = 15;
            TrisB2_label.Text = "TrisB2";
            TrisB2_label.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // TrisB3_label
            // 
            TrisB3_label.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            TrisB3_label.AutoSize = true;
            TrisB3_label.Location = new Point(212, 29);
            TrisB3_label.Name = "TrisB3_label";
            TrisB3_label.Size = new Size(34, 27);
            TrisB3_label.TabIndex = 14;
            TrisB3_label.Text = "TrisB3";
            TrisB3_label.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // TrisB4_label
            // 
            TrisB4_label.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            TrisB4_label.AutoSize = true;
            TrisB4_label.Location = new Point(171, 29);
            TrisB4_label.Name = "TrisB4_label";
            TrisB4_label.Size = new Size(34, 27);
            TrisB4_label.TabIndex = 13;
            TrisB4_label.Text = "TrisB4";
            TrisB4_label.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // TrisB5_label
            // 
            TrisB5_label.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            TrisB5_label.AutoSize = true;
            TrisB5_label.Location = new Point(130, 29);
            TrisB5_label.Name = "TrisB5_label";
            TrisB5_label.Size = new Size(34, 27);
            TrisB5_label.TabIndex = 12;
            TrisB5_label.Text = "TrisB5";
            TrisB5_label.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // TrisB6_label
            // 
            TrisB6_label.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            TrisB6_label.AutoSize = true;
            TrisB6_label.Location = new Point(89, 29);
            TrisB6_label.Name = "TrisB6_label";
            TrisB6_label.Size = new Size(34, 27);
            TrisB6_label.TabIndex = 11;
            TrisB6_label.Text = "TrisB6";
            TrisB6_label.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // TrisB7_label
            // 
            TrisB7_label.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            TrisB7_label.AutoSize = true;
            TrisB7_label.Location = new Point(48, 29);
            TrisB7_label.Name = "TrisB7_label";
            TrisB7_label.Size = new Size(34, 27);
            TrisB7_label.TabIndex = 10;
            TrisB7_label.Text = "TrisB7";
            TrisB7_label.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // label48
            // 
            label48.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            label48.AutoSize = true;
            label48.Location = new Point(4, 29);
            label48.Name = "label48";
            label48.Size = new Size(37, 27);
            label48.TabIndex = 9;
            label48.Text = "Tris";
            label48.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // label49
            // 
            label49.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            label49.AutoSize = true;
            label49.Location = new Point(335, 1);
            label49.Name = "label49";
            label49.Size = new Size(36, 27);
            label49.TabIndex = 8;
            label49.Text = "0";
            label49.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // label50
            // 
            label50.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            label50.AutoSize = true;
            label50.Location = new Point(294, 1);
            label50.Name = "label50";
            label50.Size = new Size(34, 27);
            label50.TabIndex = 7;
            label50.Text = "1";
            label50.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // label51
            // 
            label51.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            label51.AutoSize = true;
            label51.Location = new Point(253, 1);
            label51.Name = "label51";
            label51.Size = new Size(34, 27);
            label51.TabIndex = 6;
            label51.Text = "2";
            label51.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // label52
            // 
            label52.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            label52.AutoSize = true;
            label52.Location = new Point(212, 1);
            label52.Name = "label52";
            label52.Size = new Size(34, 27);
            label52.TabIndex = 5;
            label52.Text = "3";
            label52.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // label53
            // 
            label53.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            label53.AutoSize = true;
            label53.Location = new Point(171, 1);
            label53.Name = "label53";
            label53.Size = new Size(34, 27);
            label53.TabIndex = 4;
            label53.Text = "4";
            label53.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // label54
            // 
            label54.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            label54.AutoSize = true;
            label54.Location = new Point(130, 1);
            label54.Name = "label54";
            label54.Size = new Size(34, 27);
            label54.TabIndex = 3;
            label54.Text = "5";
            label54.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // label55
            // 
            label55.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            label55.AutoSize = true;
            label55.Location = new Point(89, 1);
            label55.Name = "label55";
            label55.Size = new Size(34, 27);
            label55.TabIndex = 2;
            label55.Text = "6";
            label55.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // label56
            // 
            label56.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            label56.AutoSize = true;
            label56.Location = new Point(48, 1);
            label56.Name = "label56";
            label56.Size = new Size(34, 27);
            label56.TabIndex = 1;
            label56.Text = "7";
            label56.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // label57
            // 
            label57.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            label57.AutoSize = true;
            label57.Location = new Point(4, 1);
            label57.Name = "label57";
            label57.Size = new Size(37, 27);
            label57.TabIndex = 0;
            label57.Text = "RB";
            label57.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // label58
            // 
            label58.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            label58.AutoSize = true;
            label58.Location = new Point(4, 57);
            label58.Name = "label58";
            label58.Size = new Size(37, 28);
            label58.TabIndex = 18;
            label58.Text = "Pin";
            label58.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // PinB5_button
            // 
            PinB5_button.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            PinB5_button.FlatAppearance.BorderSize = 0;
            PinB5_button.FlatStyle = FlatStyle.Flat;
            PinB5_button.Location = new Point(130, 60);
            PinB5_button.Name = "PinB5_button";
            PinB5_button.Size = new Size(34, 22);
            PinB5_button.TabIndex = 22;
            PinB5_button.Text = "Pb5";
            PinB5_button.UseVisualStyleBackColor = true;
            PinB5_button.Click += PinB5_button_Click;
            // 
            // PinB4_button
            // 
            PinB4_button.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            PinB4_button.FlatAppearance.BorderSize = 0;
            PinB4_button.FlatStyle = FlatStyle.Flat;
            PinB4_button.Location = new Point(171, 60);
            PinB4_button.Name = "PinB4_button";
            PinB4_button.Size = new Size(34, 22);
            PinB4_button.TabIndex = 21;
            PinB4_button.Text = "Pb4";
            PinB4_button.UseVisualStyleBackColor = true;
            PinB4_button.Click += PinB4_button_Click;
            // 
            // PinB2_button
            // 
            PinB2_button.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            PinB2_button.FlatAppearance.BorderSize = 0;
            PinB2_button.FlatStyle = FlatStyle.Flat;
            PinB2_button.Location = new Point(253, 60);
            PinB2_button.Name = "PinB2_button";
            PinB2_button.Size = new Size(34, 22);
            PinB2_button.TabIndex = 24;
            PinB2_button.Text = "Pb2";
            PinB2_button.UseVisualStyleBackColor = true;
            PinB2_button.Click += PinB2_button_Click;
            // 
            // PinB3_button
            // 
            PinB3_button.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            PinB3_button.FlatAppearance.BorderSize = 0;
            PinB3_button.FlatStyle = FlatStyle.Flat;
            PinB3_button.Location = new Point(212, 60);
            PinB3_button.Name = "PinB3_button";
            PinB3_button.Size = new Size(34, 22);
            PinB3_button.TabIndex = 23;
            PinB3_button.Text = "Pb3";
            PinB3_button.UseVisualStyleBackColor = true;
            PinB3_button.Click += PinB3_button_Click;
            // 
            // PinB6_button
            // 
            PinB6_button.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            PinB6_button.FlatAppearance.BorderSize = 0;
            PinB6_button.FlatStyle = FlatStyle.Flat;
            PinB6_button.Location = new Point(89, 60);
            PinB6_button.Name = "PinB6_button";
            PinB6_button.Size = new Size(34, 22);
            PinB6_button.TabIndex = 19;
            PinB6_button.Text = "Pb6";
            PinB6_button.UseVisualStyleBackColor = true;
            PinB6_button.Click += PinB6_button_Click;
            // 
            // PinB7_button
            // 
            PinB7_button.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            PinB7_button.FlatAppearance.BorderSize = 0;
            PinB7_button.FlatStyle = FlatStyle.Flat;
            PinB7_button.Location = new Point(48, 60);
            PinB7_button.Name = "PinB7_button";
            PinB7_button.Size = new Size(34, 22);
            PinB7_button.TabIndex = 20;
            PinB7_button.Text = "Pb7";
            PinB7_button.UseVisualStyleBackColor = true;
            PinB7_button.Click += PinB7_button_Click;
            // 
            // PinB1_button
            // 
            PinB1_button.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            PinB1_button.FlatAppearance.BorderSize = 0;
            PinB1_button.FlatStyle = FlatStyle.Flat;
            PinB1_button.Location = new Point(294, 60);
            PinB1_button.Name = "PinB1_button";
            PinB1_button.Size = new Size(34, 22);
            PinB1_button.TabIndex = 25;
            PinB1_button.Text = "Pb1";
            PinB1_button.UseVisualStyleBackColor = true;
            PinB1_button.Click += PinB1_button_Click;
            // 
            // PinB0_button
            // 
            PinB0_button.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            PinB0_button.FlatAppearance.BorderSize = 0;
            PinB0_button.FlatStyle = FlatStyle.Flat;
            PinB0_button.Location = new Point(335, 60);
            PinB0_button.Name = "PinB0_button";
            PinB0_button.Size = new Size(36, 22);
            PinB0_button.TabIndex = 26;
            PinB0_button.Text = "Pb0";
            PinB0_button.UseVisualStyleBackColor = true;
            PinB0_button.Click += PinB0_button_Click;
            // 
            // tableLayoutPanel6
            // 
            tableLayoutPanel6.CellBorderStyle = TableLayoutPanelCellBorderStyle.Single;
            tableLayoutPanel6.ColumnCount = 9;
            tableLayoutPanel6.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 12F));
            tableLayoutPanel6.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 11F));
            tableLayoutPanel6.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 11F));
            tableLayoutPanel6.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 11F));
            tableLayoutPanel6.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 11F));
            tableLayoutPanel6.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 11F));
            tableLayoutPanel6.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 11F));
            tableLayoutPanel6.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 11F));
            tableLayoutPanel6.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 11F));
            tableLayoutPanel6.Controls.Add(TrisA0_label, 8, 1);
            tableLayoutPanel6.Controls.Add(TrisA1_label, 7, 1);
            tableLayoutPanel6.Controls.Add(TrisA2_label, 6, 1);
            tableLayoutPanel6.Controls.Add(TrisA3_label, 5, 1);
            tableLayoutPanel6.Controls.Add(TrisA4_label, 4, 1);
            tableLayoutPanel6.Controls.Add(TrisA5_label, 3, 1);
            tableLayoutPanel6.Controls.Add(TrisA6_label, 2, 1);
            tableLayoutPanel6.Controls.Add(TrisA7_label, 1, 1);
            tableLayoutPanel6.Controls.Add(label37, 0, 1);
            tableLayoutPanel6.Controls.Add(label36, 8, 0);
            tableLayoutPanel6.Controls.Add(label35, 7, 0);
            tableLayoutPanel6.Controls.Add(label34, 6, 0);
            tableLayoutPanel6.Controls.Add(label33, 5, 0);
            tableLayoutPanel6.Controls.Add(label32, 4, 0);
            tableLayoutPanel6.Controls.Add(label31, 3, 0);
            tableLayoutPanel6.Controls.Add(label30, 2, 0);
            tableLayoutPanel6.Controls.Add(label29, 1, 0);
            tableLayoutPanel6.Controls.Add(label28, 0, 0);
            tableLayoutPanel6.Controls.Add(label39, 0, 2);
            tableLayoutPanel6.Controls.Add(PinA5_button, 3, 2);
            tableLayoutPanel6.Controls.Add(PinA4_button, 4, 2);
            tableLayoutPanel6.Controls.Add(PinA2_button, 6, 2);
            tableLayoutPanel6.Controls.Add(PinA3_button, 5, 2);
            tableLayoutPanel6.Controls.Add(PinA6_button, 2, 2);
            tableLayoutPanel6.Controls.Add(PinA7_button, 1, 2);
            tableLayoutPanel6.Controls.Add(PinA1_button, 7, 2);
            tableLayoutPanel6.Controls.Add(PinA0_button, 8, 2);
            tableLayoutPanel6.Font = new Font("Arial Narrow", 7.8F, FontStyle.Regular, GraphicsUnit.Point);
            tableLayoutPanel6.Location = new Point(3, 3);
            tableLayoutPanel6.Name = "tableLayoutPanel6";
            tableLayoutPanel6.RowCount = 3;
            tableLayoutPanel6.RowStyles.Add(new RowStyle(SizeType.Percent, 34F));
            tableLayoutPanel6.RowStyles.Add(new RowStyle(SizeType.Percent, 33F));
            tableLayoutPanel6.RowStyles.Add(new RowStyle(SizeType.Percent, 33F));
            tableLayoutPanel6.Size = new Size(375, 86);
            tableLayoutPanel6.TabIndex = 0;
            // 
            // TrisA0_label
            // 
            TrisA0_label.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            TrisA0_label.AutoSize = true;
            TrisA0_label.Location = new Point(335, 29);
            TrisA0_label.Name = "TrisA0_label";
            TrisA0_label.Size = new Size(36, 27);
            TrisA0_label.TabIndex = 17;
            TrisA0_label.Text = "TrisA0";
            TrisA0_label.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // TrisA1_label
            // 
            TrisA1_label.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            TrisA1_label.AutoSize = true;
            TrisA1_label.Location = new Point(294, 29);
            TrisA1_label.Name = "TrisA1_label";
            TrisA1_label.Size = new Size(34, 27);
            TrisA1_label.TabIndex = 16;
            TrisA1_label.Text = "TrisA1";
            TrisA1_label.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // TrisA2_label
            // 
            TrisA2_label.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            TrisA2_label.AutoSize = true;
            TrisA2_label.Location = new Point(253, 29);
            TrisA2_label.Name = "TrisA2_label";
            TrisA2_label.Size = new Size(34, 27);
            TrisA2_label.TabIndex = 15;
            TrisA2_label.Text = "TrisA2";
            TrisA2_label.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // TrisA3_label
            // 
            TrisA3_label.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            TrisA3_label.AutoSize = true;
            TrisA3_label.Location = new Point(212, 29);
            TrisA3_label.Name = "TrisA3_label";
            TrisA3_label.Size = new Size(34, 27);
            TrisA3_label.TabIndex = 14;
            TrisA3_label.Text = "TrisA3";
            TrisA3_label.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // TrisA4_label
            // 
            TrisA4_label.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            TrisA4_label.AutoSize = true;
            TrisA4_label.Location = new Point(171, 29);
            TrisA4_label.Name = "TrisA4_label";
            TrisA4_label.Size = new Size(34, 27);
            TrisA4_label.TabIndex = 13;
            TrisA4_label.Text = "TrisA4";
            TrisA4_label.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // TrisA5_label
            // 
            TrisA5_label.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            TrisA5_label.AutoSize = true;
            TrisA5_label.Location = new Point(130, 29);
            TrisA5_label.Name = "TrisA5_label";
            TrisA5_label.Size = new Size(34, 27);
            TrisA5_label.TabIndex = 12;
            TrisA5_label.Text = "TrisA5";
            TrisA5_label.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // TrisA6_label
            // 
            TrisA6_label.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            TrisA6_label.AutoSize = true;
            TrisA6_label.Location = new Point(89, 29);
            TrisA6_label.Name = "TrisA6_label";
            TrisA6_label.Size = new Size(34, 27);
            TrisA6_label.TabIndex = 11;
            TrisA6_label.Text = "TrisA6";
            TrisA6_label.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // TrisA7_label
            // 
            TrisA7_label.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            TrisA7_label.AutoSize = true;
            TrisA7_label.Location = new Point(48, 29);
            TrisA7_label.Name = "TrisA7_label";
            TrisA7_label.Size = new Size(34, 27);
            TrisA7_label.TabIndex = 10;
            TrisA7_label.Text = "TrisA7";
            TrisA7_label.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // label37
            // 
            label37.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            label37.AutoSize = true;
            label37.Location = new Point(4, 29);
            label37.Name = "label37";
            label37.Size = new Size(37, 27);
            label37.TabIndex = 9;
            label37.Text = "Tris";
            label37.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // label36
            // 
            label36.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            label36.AutoSize = true;
            label36.Location = new Point(335, 1);
            label36.Name = "label36";
            label36.Size = new Size(36, 27);
            label36.TabIndex = 8;
            label36.Text = "0";
            label36.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // label35
            // 
            label35.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            label35.AutoSize = true;
            label35.Location = new Point(294, 1);
            label35.Name = "label35";
            label35.Size = new Size(34, 27);
            label35.TabIndex = 7;
            label35.Text = "1";
            label35.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // label34
            // 
            label34.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            label34.AutoSize = true;
            label34.Location = new Point(253, 1);
            label34.Name = "label34";
            label34.Size = new Size(34, 27);
            label34.TabIndex = 6;
            label34.Text = "2";
            label34.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // label33
            // 
            label33.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            label33.AutoSize = true;
            label33.Location = new Point(212, 1);
            label33.Name = "label33";
            label33.Size = new Size(34, 27);
            label33.TabIndex = 5;
            label33.Text = "3";
            label33.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // label32
            // 
            label32.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            label32.AutoSize = true;
            label32.Location = new Point(171, 1);
            label32.Name = "label32";
            label32.Size = new Size(34, 27);
            label32.TabIndex = 4;
            label32.Text = "4";
            label32.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // label31
            // 
            label31.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            label31.AutoSize = true;
            label31.Location = new Point(130, 1);
            label31.Name = "label31";
            label31.Size = new Size(34, 27);
            label31.TabIndex = 3;
            label31.Text = "5";
            label31.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // label30
            // 
            label30.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            label30.AutoSize = true;
            label30.Location = new Point(89, 1);
            label30.Name = "label30";
            label30.Size = new Size(34, 27);
            label30.TabIndex = 2;
            label30.Text = "6";
            label30.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // label29
            // 
            label29.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            label29.AutoSize = true;
            label29.Location = new Point(48, 1);
            label29.Name = "label29";
            label29.Size = new Size(34, 27);
            label29.TabIndex = 1;
            label29.Text = "7";
            label29.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // label28
            // 
            label28.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            label28.AutoSize = true;
            label28.Location = new Point(4, 1);
            label28.Name = "label28";
            label28.Size = new Size(37, 27);
            label28.TabIndex = 0;
            label28.Text = "RA";
            label28.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // label39
            // 
            label39.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            label39.AutoSize = true;
            label39.Location = new Point(4, 57);
            label39.Name = "label39";
            label39.Size = new Size(37, 28);
            label39.TabIndex = 18;
            label39.Text = "Pin";
            label39.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // PinA5_button
            // 
            PinA5_button.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            PinA5_button.FlatAppearance.BorderSize = 0;
            PinA5_button.FlatStyle = FlatStyle.Flat;
            PinA5_button.Location = new Point(130, 60);
            PinA5_button.Name = "PinA5_button";
            PinA5_button.Size = new Size(34, 22);
            PinA5_button.TabIndex = 22;
            PinA5_button.Text = "Pa5";
            PinA5_button.UseVisualStyleBackColor = true;
            PinA5_button.Click += PinA5_button_Click;
            // 
            // PinA4_button
            // 
            PinA4_button.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            PinA4_button.FlatAppearance.BorderSize = 0;
            PinA4_button.FlatStyle = FlatStyle.Flat;
            PinA4_button.Location = new Point(171, 60);
            PinA4_button.Name = "PinA4_button";
            PinA4_button.Size = new Size(34, 22);
            PinA4_button.TabIndex = 21;
            PinA4_button.Text = "Pa4";
            PinA4_button.UseVisualStyleBackColor = true;
            PinA4_button.Click += PinA4_button_Click;
            // 
            // PinA2_button
            // 
            PinA2_button.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            PinA2_button.FlatAppearance.BorderSize = 0;
            PinA2_button.FlatStyle = FlatStyle.Flat;
            PinA2_button.Location = new Point(253, 60);
            PinA2_button.Name = "PinA2_button";
            PinA2_button.Size = new Size(34, 22);
            PinA2_button.TabIndex = 24;
            PinA2_button.Text = "Pa2";
            PinA2_button.UseVisualStyleBackColor = true;
            PinA2_button.Click += PinA2_button_Click;
            // 
            // PinA3_button
            // 
            PinA3_button.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            PinA3_button.FlatAppearance.BorderSize = 0;
            PinA3_button.FlatStyle = FlatStyle.Flat;
            PinA3_button.Location = new Point(212, 60);
            PinA3_button.Name = "PinA3_button";
            PinA3_button.Size = new Size(34, 22);
            PinA3_button.TabIndex = 23;
            PinA3_button.Text = "Pa3";
            PinA3_button.UseVisualStyleBackColor = true;
            PinA3_button.Click += PinA3_button_Click;
            // 
            // PinA6_button
            // 
            PinA6_button.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            PinA6_button.FlatAppearance.BorderSize = 0;
            PinA6_button.FlatStyle = FlatStyle.Flat;
            PinA6_button.Location = new Point(89, 60);
            PinA6_button.Name = "PinA6_button";
            PinA6_button.Size = new Size(34, 22);
            PinA6_button.TabIndex = 19;
            PinA6_button.Text = "Pa6";
            PinA6_button.UseVisualStyleBackColor = true;
            PinA6_button.Click += PinA6_button_Click;
            // 
            // PinA7_button
            // 
            PinA7_button.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            PinA7_button.FlatAppearance.BorderSize = 0;
            PinA7_button.FlatStyle = FlatStyle.Flat;
            PinA7_button.Location = new Point(48, 60);
            PinA7_button.Name = "PinA7_button";
            PinA7_button.Size = new Size(34, 22);
            PinA7_button.TabIndex = 20;
            PinA7_button.Text = "Pa7";
            PinA7_button.UseVisualStyleBackColor = true;
            PinA7_button.Click += PinA7_button_Click;
            // 
            // PinA1_button
            // 
            PinA1_button.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            PinA1_button.FlatAppearance.BorderSize = 0;
            PinA1_button.FlatStyle = FlatStyle.Flat;
            PinA1_button.Location = new Point(294, 60);
            PinA1_button.Name = "PinA1_button";
            PinA1_button.Size = new Size(34, 22);
            PinA1_button.TabIndex = 25;
            PinA1_button.Text = "Pa1";
            PinA1_button.UseVisualStyleBackColor = true;
            PinA1_button.Click += PinA1_button_Click;
            // 
            // PinA0_button
            // 
            PinA0_button.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            PinA0_button.FlatAppearance.BorderSize = 0;
            PinA0_button.FlatStyle = FlatStyle.Flat;
            PinA0_button.Location = new Point(335, 60);
            PinA0_button.Name = "PinA0_button";
            PinA0_button.Size = new Size(36, 22);
            PinA0_button.TabIndex = 26;
            PinA0_button.Text = "Pa0";
            PinA0_button.UseVisualStyleBackColor = true;
            PinA0_button.Click += PinA0_button_Click;
            // 
            // T0SE_Toggle
            // 
            T0SE_Toggle.Font = new Font("Arial", 9F, FontStyle.Bold, GraphicsUnit.Point);
            T0SE_Toggle.Location = new Point(598, 462);
            T0SE_Toggle.Name = "T0SE_Toggle";
            T0SE_Toggle.ReadOnly = true;
            T0SE_Toggle.Size = new Size(16, 21);
            T0SE_Toggle.TabIndex = 104;
            T0SE_Toggle.TabStop = false;
            T0SE_Toggle.TextAlign = HorizontalAlignment.Center;
            T0SE_Toggle.MouseClick += T0SE_Toggle_MouseClick;
            // 
            // panel4
            // 
            panel4.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            panel4.Controls.Add(dataGridView1);
            panel4.Controls.Add(panel3);
            panel4.Dock = DockStyle.Left;
            panel4.Location = new Point(0, 0);
            panel4.Name = "panel4";
            panel4.Size = new Size(412, 587);
            panel4.TabIndex = 102;
            // 
            // dataGridView1
            // 
            dataGridView1.AllowUserToAddRows = false;
            dataGridView1.AllowUserToDeleteRows = false;
            dataGridView1.AllowUserToResizeColumns = false;
            dataGridView1.AllowUserToResizeRows = false;
            dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dataGridView1.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells;
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Columns.AddRange(new DataGridViewColumn[] { Column9, Column1, Column2, Column3, Column4, Column5, Column6, Column7, Column8 });
            dataGridViewCellStyle1.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = SystemColors.Window;
            dataGridViewCellStyle1.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            dataGridViewCellStyle1.ForeColor = SystemColors.ControlText;
            dataGridViewCellStyle1.Format = "X02";
            dataGridViewCellStyle1.NullValue = null;
            dataGridViewCellStyle1.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = DataGridViewTriState.False;
            dataGridView1.DefaultCellStyle = dataGridViewCellStyle1;
            dataGridView1.Dock = DockStyle.Top;
            dataGridView1.EditMode = DataGridViewEditMode.EditProgrammatically;
            dataGridView1.Location = new Point(0, 0);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.ReadOnly = true;
            dataGridView1.RowHeadersVisible = false;
            dataGridView1.RowHeadersWidth = 35;
            dataGridView1.RowTemplate.Height = 25;
            dataGridView1.Size = new Size(412, 305);
            dataGridView1.TabIndex = 99;
            dataGridView1.TabStop = false;
            // 
            // Column9
            // 
            Column9.HeaderText = "";
            Column9.MinimumWidth = 6;
            Column9.Name = "Column9";
            Column9.ReadOnly = true;
            // 
            // Column1
            // 
            Column1.AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader;
            Column1.HeaderText = "00";
            Column1.MinimumWidth = 6;
            Column1.Name = "Column1";
            Column1.ReadOnly = true;
            Column1.Width = 44;
            // 
            // Column2
            // 
            Column2.AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader;
            Column2.HeaderText = "01";
            Column2.MinimumWidth = 6;
            Column2.Name = "Column2";
            Column2.ReadOnly = true;
            Column2.Width = 44;
            // 
            // Column3
            // 
            Column3.AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader;
            Column3.HeaderText = "02";
            Column3.MinimumWidth = 6;
            Column3.Name = "Column3";
            Column3.ReadOnly = true;
            Column3.Width = 44;
            // 
            // Column4
            // 
            Column4.AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader;
            Column4.HeaderText = "03";
            Column4.MinimumWidth = 6;
            Column4.Name = "Column4";
            Column4.ReadOnly = true;
            Column4.Width = 44;
            // 
            // Column5
            // 
            Column5.AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader;
            Column5.HeaderText = "04";
            Column5.MinimumWidth = 6;
            Column5.Name = "Column5";
            Column5.ReadOnly = true;
            Column5.Width = 44;
            // 
            // Column6
            // 
            Column6.AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader;
            Column6.HeaderText = "05";
            Column6.MinimumWidth = 6;
            Column6.Name = "Column6";
            Column6.ReadOnly = true;
            Column6.Width = 44;
            // 
            // Column7
            // 
            Column7.AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader;
            Column7.HeaderText = "06";
            Column7.MinimumWidth = 6;
            Column7.Name = "Column7";
            Column7.ReadOnly = true;
            Column7.Width = 44;
            // 
            // Column8
            // 
            Column8.AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader;
            Column8.HeaderText = "07";
            Column8.MinimumWidth = 6;
            Column8.Name = "Column8";
            Column8.ReadOnly = true;
            Column8.Width = 44;
            // 
            // panel3
            // 
            panel3.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            panel3.Controls.Add(Status);
            panel3.Controls.Add(textBox5);
            panel3.Controls.Add(textBox10);
            panel3.Controls.Add(label6);
            panel3.Controls.Add(label5);
            panel3.Controls.Add(textBox1);
            panel3.Controls.Add(label7);
            panel3.Controls.Add(label9);
            panel3.Controls.Add(textBox9);
            panel3.Controls.Add(label1);
            panel3.Controls.Add(textBox6);
            panel3.Controls.Add(textBox7);
            panel3.Controls.Add(label8);
            panel3.Controls.Add(textBox8);
            panel3.Dock = DockStyle.Bottom;
            panel3.Location = new Point(0, 310);
            panel3.Name = "panel3";
            panel3.Size = new Size(412, 277);
            panel3.TabIndex = 101;
            // 
            // Status
            // 
            Status.AutoSize = true;
            Status.Location = new Point(113, 46);
            Status.Name = "Status";
            Status.Size = new Size(35, 15);
            Status.TabIndex = 117;
            Status.Text = "Stack";
            // 
            // textBox5
            // 
            textBox5.Location = new Point(155, 42);
            textBox5.Name = "textBox5";
            textBox5.ReadOnly = true;
            textBox5.Size = new Size(39, 23);
            textBox5.TabIndex = 116;
            // 
            // textBox10
            // 
            textBox10.Location = new Point(155, 14);
            textBox10.Name = "textBox10";
            textBox10.ReadOnly = true;
            textBox10.Size = new Size(39, 23);
            textBox10.TabIndex = 22;
            textBox10.TabStop = false;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(12, 75);
            label6.Name = "label6";
            label6.Size = new Size(28, 15);
            label6.TabIndex = 19;
            label6.Text = "PCL";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(12, 46);
            label5.Name = "label5";
            label5.Size = new Size(26, 15);
            label5.TabIndex = 18;
            label5.Text = "FSR";
            // 
            // textBox1
            // 
            textBox1.Location = new Point(65, 14);
            textBox1.Name = "textBox1";
            textBox1.ReadOnly = true;
            textBox1.Size = new Size(40, 23);
            textBox1.TabIndex = 5;
            textBox1.TabStop = false;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(12, 104);
            label7.Name = "label7";
            label7.Size = new Size(50, 15);
            label7.TabIndex = 20;
            label7.Text = "PCLATH";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(127, 19);
            label9.Name = "label9";
            label9.Size = new Size(22, 15);
            label9.TabIndex = 23;
            label9.Text = "PC";
            // 
            // textBox9
            // 
            textBox9.Location = new Point(65, 130);
            textBox9.Name = "textBox9";
            textBox9.ReadOnly = true;
            textBox9.Size = new Size(40, 23);
            textBox9.TabIndex = 17;
            textBox9.TabStop = false;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(11, 19);
            label1.Name = "label1";
            label1.Size = new Size(36, 15);
            label1.TabIndex = 9;
            label1.Text = "wReg\r\n";
            // 
            // textBox6
            // 
            textBox6.Location = new Point(65, 43);
            textBox6.Name = "textBox6";
            textBox6.ReadOnly = true;
            textBox6.Size = new Size(40, 23);
            textBox6.TabIndex = 14;
            textBox6.TabStop = false;
            // 
            // textBox7
            // 
            textBox7.Location = new Point(65, 72);
            textBox7.Name = "textBox7";
            textBox7.ReadOnly = true;
            textBox7.Size = new Size(40, 23);
            textBox7.TabIndex = 15;
            textBox7.TabStop = false;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(11, 133);
            label8.Name = "label8";
            label8.Size = new Size(39, 15);
            label8.TabIndex = 21;
            label8.Text = "Status";
            // 
            // textBox8
            // 
            textBox8.Location = new Point(65, 101);
            textBox8.Name = "textBox8";
            textBox8.ReadOnly = true;
            textBox8.Size = new Size(40, 23);
            textBox8.TabIndex = 16;
            textBox8.TabStop = false;
            // 
            // panel2
            // 
            panel2.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            panel2.Controls.Add(label22);
            panel2.Controls.Add(label21);
            panel2.Controls.Add(quarzFreq_comboBox);
            panel2.Controls.Add(BP_skip_CB);
            panel2.Controls.Add(Einlesen_Btn);
            panel2.Controls.Add(label10);
            panel2.Controls.Add(laufzeit_TB);
            panel2.Controls.Add(Automatic_Btn);
            panel2.Controls.Add(zykluszeit_TB);
            panel2.Controls.Add(Zurücksetzen_Btn);
            panel2.Controls.Add(label11);
            panel2.Controls.Add(Einzelschritt_Btn);
            panel2.Dock = DockStyle.Right;
            panel2.Location = new Point(809, 0);
            panel2.Name = "panel2";
            panel2.Size = new Size(190, 587);
            panel2.TabIndex = 100;
            // 
            // label22
            // 
            label22.AutoSize = true;
            label22.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point);
            label22.Location = new Point(20, 178);
            label22.Name = "label22";
            label22.Size = new Size(122, 15);
            label22.TabIndex = 33;
            label22.Text = "Programmsteuerung";
            // 
            // label21
            // 
            label21.AutoSize = true;
            label21.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point);
            label21.Location = new Point(18, 7);
            label21.Name = "label21";
            label21.Size = new Size(86, 15);
            label21.TabIndex = 32;
            label21.Text = "Quarzfrequenz";
            // 
            // quarzFreq_comboBox
            // 
            quarzFreq_comboBox.AutoCompleteMode = AutoCompleteMode.Append;
            quarzFreq_comboBox.AutoCompleteSource = AutoCompleteSource.ListItems;
            quarzFreq_comboBox.DropDownStyle = ComboBoxStyle.DropDownList;
            quarzFreq_comboBox.FlatStyle = FlatStyle.Popup;
            quarzFreq_comboBox.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point);
            quarzFreq_comboBox.Items.AddRange(new object[] { "1 kHz (4000µs/Cycle)", "25 kHz (160µs/Cycle)", "100 kHz (40µs/Cycle)", "200 kHz (20µs/Cycle)", "455 kHz (8,791µs/Cycle)", "2 MHz (2µs/cycle)", "4 MHz (1µs/cycle)", "10 MHz (400ns/cycle)" });
            quarzFreq_comboBox.Location = new Point(18, 28);
            quarzFreq_comboBox.Margin = new Padding(2);
            quarzFreq_comboBox.Name = "quarzFreq_comboBox";
            quarzFreq_comboBox.Size = new Size(155, 23);
            quarzFreq_comboBox.TabIndex = 31;
            quarzFreq_comboBox.SelectedIndexChanged += quarzFreq_comboBox_SelectedIndexChanged;
            // 
            // BP_skip_CB
            // 
            BP_skip_CB.AutoSize = true;
            BP_skip_CB.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point);
            BP_skip_CB.Location = new Point(18, 328);
            BP_skip_CB.Margin = new Padding(3, 2, 3, 2);
            BP_skip_CB.Name = "BP_skip_CB";
            BP_skip_CB.Size = new Size(162, 19);
            BP_skip_CB.TabIndex = 30;
            BP_skip_CB.Text = "Breakpoint übersrpingen";
            BP_skip_CB.UseVisualStyleBackColor = true;
            BP_skip_CB.CheckedChanged += BP_skip_CB_CheckedChanged;
            // 
            // Einlesen_Btn
            // 
            Einlesen_Btn.Location = new Point(18, 352);
            Einlesen_Btn.Margin = new Padding(3, 2, 3, 2);
            Einlesen_Btn.Name = "Einlesen_Btn";
            Einlesen_Btn.Size = new Size(155, 38);
            Einlesen_Btn.TabIndex = 1;
            Einlesen_Btn.Text = "Datei Auswählen";
            Einlesen_Btn.UseVisualStyleBackColor = true;
            Einlesen_Btn.Click += Einlesen_Btn_Click;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point);
            label10.Location = new Point(18, 62);
            label10.Name = "label10";
            label10.Size = new Size(89, 15);
            label10.TabIndex = 26;
            label10.Text = "Gesamtlaufzeit";
            // 
            // laufzeit_TB
            // 
            laufzeit_TB.Location = new Point(18, 80);
            laufzeit_TB.Name = "laufzeit_TB";
            laufzeit_TB.ReadOnly = true;
            laufzeit_TB.Size = new Size(155, 23);
            laufzeit_TB.TabIndex = 25;
            laufzeit_TB.TabStop = false;
            // 
            // Automatic_Btn
            // 
            Automatic_Btn.Location = new Point(18, 239);
            Automatic_Btn.Margin = new Padding(3, 2, 3, 2);
            Automatic_Btn.Name = "Automatic_Btn";
            Automatic_Btn.Size = new Size(155, 38);
            Automatic_Btn.TabIndex = 29;
            Automatic_Btn.Text = "Start";
            Automatic_Btn.UseVisualStyleBackColor = true;
            Automatic_Btn.MouseClick += Automatic_Btn_MouseClick;
            // 
            // zykluszeit_TB
            // 
            zykluszeit_TB.Location = new Point(18, 134);
            zykluszeit_TB.Name = "zykluszeit_TB";
            zykluszeit_TB.ReadOnly = true;
            zykluszeit_TB.Size = new Size(155, 23);
            zykluszeit_TB.TabIndex = 24;
            zykluszeit_TB.TabStop = false;
            // 
            // Zurücksetzen_Btn
            // 
            Zurücksetzen_Btn.Location = new Point(18, 197);
            Zurücksetzen_Btn.Margin = new Padding(3, 2, 3, 2);
            Zurücksetzen_Btn.Name = "Zurücksetzen_Btn";
            Zurücksetzen_Btn.Size = new Size(155, 38);
            Zurücksetzen_Btn.TabIndex = 3;
            Zurücksetzen_Btn.Text = "Zurücksetzen";
            Zurücksetzen_Btn.UseVisualStyleBackColor = true;
            Zurücksetzen_Btn.Click += Zurücksetzen_Btn_Click;
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point);
            label11.Location = new Point(18, 116);
            label11.Name = "label11";
            label11.Size = new Size(60, 15);
            label11.TabIndex = 27;
            label11.Text = "Zykluszeit";
            // 
            // Einzelschritt_Btn
            // 
            Einzelschritt_Btn.Location = new Point(18, 283);
            Einzelschritt_Btn.Margin = new Padding(3, 2, 3, 2);
            Einzelschritt_Btn.Name = "Einzelschritt_Btn";
            Einzelschritt_Btn.Size = new Size(155, 38);
            Einzelschritt_Btn.TabIndex = 2;
            Einzelschritt_Btn.Text = "Einzelschritt";
            Einzelschritt_Btn.UseVisualStyleBackColor = true;
            Einzelschritt_Btn.Click += Einzelschritt_Btn_Click;
            // 
            // T0CS_Toggle
            // 
            T0CS_Toggle.Font = new Font("Arial", 9F, FontStyle.Bold, GraphicsUnit.Point);
            T0CS_Toggle.Location = new Point(560, 462);
            T0CS_Toggle.Name = "T0CS_Toggle";
            T0CS_Toggle.ReadOnly = true;
            T0CS_Toggle.Size = new Size(16, 21);
            T0CS_Toggle.TabIndex = 103;
            T0CS_Toggle.TabStop = false;
            T0CS_Toggle.TextAlign = HorizontalAlignment.Center;
            T0CS_Toggle.MouseClick += T0CS_Toggle_MouseClick;
            // 
            // Ausgabe_LV
            // 
            Ausgabe_LV.AutoArrange = false;
            Ausgabe_LV.BorderStyle = BorderStyle.FixedSingle;
            Ausgabe_LV.CheckBoxes = true;
            Ausgabe_LV.Columns.AddRange(new ColumnHeader[] { Textanzeige_LV });
            Ausgabe_LV.Dock = DockStyle.Right;
            Ausgabe_LV.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point);
            Ausgabe_LV.FullRowSelect = true;
            Ausgabe_LV.HeaderStyle = ColumnHeaderStyle.None;
            Ausgabe_LV.HideSelection = true;
            Ausgabe_LV.LabelWrap = false;
            Ausgabe_LV.Location = new Point(999, 0);
            Ausgabe_LV.MultiSelect = false;
            Ausgabe_LV.Name = "Ausgabe_LV";
            Ausgabe_LV.ShowGroups = false;
            Ausgabe_LV.Size = new Size(405, 587);
            Ausgabe_LV.TabIndex = 28;
            Ausgabe_LV.TabStop = false;
            Ausgabe_LV.UseCompatibleStateImageBehavior = false;
            Ausgabe_LV.View = View.Details;
            Ausgabe_LV.MouseClick += Ausgabe_LV_MouseClick;
            // 
            // INTEDG_Toggle
            // 
            INTEDG_Toggle.Font = new Font("Arial", 9F, FontStyle.Bold, GraphicsUnit.Point);
            INTEDG_Toggle.Location = new Point(522, 462);
            INTEDG_Toggle.Name = "INTEDG_Toggle";
            INTEDG_Toggle.ReadOnly = true;
            INTEDG_Toggle.Size = new Size(16, 21);
            INTEDG_Toggle.TabIndex = 28;
            INTEDG_Toggle.TabStop = false;
            INTEDG_Toggle.TextAlign = HorizontalAlignment.Center;
            INTEDG_Toggle.MouseClick += INTEDG_Toggle_MouseClick;
            // 
            // RPBU_Toggle
            // 
            RPBU_Toggle.Font = new Font("Arial", 9F, FontStyle.Bold, GraphicsUnit.Point);
            RPBU_Toggle.Location = new Point(484, 462);
            RPBU_Toggle.Name = "RPBU_Toggle";
            RPBU_Toggle.ReadOnly = true;
            RPBU_Toggle.Size = new Size(16, 21);
            RPBU_Toggle.TabIndex = 27;
            RPBU_Toggle.TabStop = false;
            RPBU_Toggle.TextAlign = HorizontalAlignment.Center;
            RPBU_Toggle.MouseClick += RPBU_Toggle_MouseClick;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1404, 587);
            Controls.Add(panel1);
            Margin = new Padding(3, 2, 3, 2);
            Name = "Form1";
            Text = "Form1";
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            panel5.ResumeLayout(false);
            tableLayoutPanel7.ResumeLayout(false);
            tableLayoutPanel7.PerformLayout();
            tableLayoutPanel6.ResumeLayout(false);
            tableLayoutPanel6.PerformLayout();
            panel4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            panel3.ResumeLayout(false);
            panel3.PerformLayout();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ResumeLayout(false);
        }

        #endregion
        private Panel panel1;
        private Button Einlesen_Btn;
        private Button Einzelschritt_Btn;
        private Button Zurücksetzen_Btn;
        private TextBox zykluszeit_TB;
        private TextBox laufzeit_TB;
        private Label label11;
        private Label label10;
        private ListView Ausgabe_LV;
        private ColumnHeader Textanzeige_LV;
        private Button Automatic_Btn;
        private DataGridView dataGridView1;
        private DataGridViewTextBoxColumn Column9;
        private DataGridViewTextBoxColumn Column1;
        private DataGridViewTextBoxColumn Column2;
        private DataGridViewTextBoxColumn Column3;
        private DataGridViewTextBoxColumn Column4;
        private DataGridViewTextBoxColumn Column5;
        private DataGridViewTextBoxColumn Column6;
        private DataGridViewTextBoxColumn Column7;
        private DataGridViewTextBoxColumn Column8;
        private TextBox textBox10;
        private TextBox textBox1;
        private Label label9;
        private TextBox textBox7;
        private TextBox textBox8;
        private Label label8;
        private TextBox textBox6;
        private Label label1;
        private TextBox textBox9;
        private Label label7;
        private Label label5;
        private Label label6;
        private Panel panel2;
        private Panel panel4;
        private Panel panel3;
        private TextBox option_out;
        private Label label12;
        private TextBox T0SE_Toggle;
        private TextBox T0CS_Toggle;
        private TextBox INTEDG_Toggle;
        private TextBox RPBU_Toggle;
        private Label label20;
        private Label label19;
        private Label label18;
        private Label label17;
        private Label label16;
        private Label label15;
        private Label label14;
        private Label label13;
        private TextBox PS0_Toggle;
        private TextBox PS1_Toggle;
        private TextBox PS2_Toggle;
        private TextBox PSA_Toggle;
        private CheckBox BP_skip_CB;
        private Panel panel5;
        private TableLayoutPanel tableLayoutPanel7;
        private Label TrisB0_label;
        private Label TrisB1_label;
        private Label TrisB2_label;
        private Label TrisB3_label;
        private Label TrisB4_label;
        private Label TrisB5_label;
        private Label TrisB6_label;
        private Label TrisB7_label;
        private Label label48;
        private Label label49;
        private Label label50;
        private Label label51;
        private Label label52;
        private Label label53;
        private Label label54;
        private Label label55;
        private Label label56;
        private Label label57;
        private Label label58;
        private Button PinB5_button;
        private Button PinB4_button;
        private Button PinB2_button;
        private Button PinB3_button;
        private Button PinB6_button;
        private Button PinB7_button;
        private Button PinB1_button;
        private Button PinB0_button;
        private TableLayoutPanel tableLayoutPanel6;
        private Label TrisA0_label;
        private Label TrisA1_label;
        private Label TrisA2_label;
        private Label TrisA3_label;
        private Label TrisA4_label;
        private Label TrisA5_label;
        private Label TrisA6_label;
        private Label TrisA7_label;
        private Label label37;
        private Label label36;
        private Label label35;
        private Label label34;
        private Label label33;
        private Label label32;
        private Label label31;
        private Label label30;
        private Label label29;
        private Label label28;
        private Label label39;
        private Button PinA5_button;
        private Button PinA4_button;
        private Button PinA2_button;
        private Button PinA3_button;
        private Button PinA6_button;
        private Button PinA7_button;
        private Button PinA1_button;
        private Button PinA0_button;
        private Label label22;
        private Label label21;
        private ComboBox quarzFreq_comboBox;
        private Label Status;
        private TextBox textBox5;
        private Label label23;
        private Label label24;
        private TextBox textBox11;
        private Label label25;
        private Label label26;
        private Label label27;
        private Label label38;
        private Label label40;
        private Label label41;
        private Label label42;
        private TextBox textBox12;
        private TextBox textBox13;
        private TextBox textBox14;
        private TextBox textBox15;
        private TextBox textBox16;
        private TextBox textBox17;
        private TextBox textBox18;
        private TextBox textBox19;
        private TextBox RBIF_Toggle;
        private TextBox INTF_Toggle;
        private TextBox T0IF_Toggle;
        private TextBox RBIE_Toggle;
        private TextBox INTE_Toggle;
        private TextBox T0IE_Toggle;
        private TextBox PIE_Toggle;
        private TextBox GIE_Toggle;
        private TextBox intcon_out;
        private Label label43;
        private Label label44;
        private Label label45;
        private Label label46;
        private Label label47;
        private Label label59;
        private Label label60;
        private Label label61;
        private TextBox textBox2;
        private TextBox textBox3;
        private TextBox textBox4;
        private TextBox textBox23;
        private TextBox textBox24;
        private TextBox textBox25;
        private TextBox textBox26;
        private TextBox textBox27;
    }
}